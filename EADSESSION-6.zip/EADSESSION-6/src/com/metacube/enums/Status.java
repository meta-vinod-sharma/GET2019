package com.metacube.enums;

public enum Status {
	ADDED, UPDATED, DELETED,INSERTED, FAILED;
}
